

import setuptools
from setuptools import setup

setup(name='example_pkg_ObesePanda111',
      version='3.7.1',
      description='the albanian flag',
      url='https://github.com/RydenKaye/Albania',
      author='ObesePanda',
      author_email='rydenkaye@gmail.com',
      license='MIT',
      packages = setuptools.find_packages("Albania"),
      zip_safe=False,
      include_package_data=True
      )
